CREATE TABLE Cliente (
Rut Varchar2(50) Primary Key,
Nombre Varchar2(50),
Contraseña Varchar2(20),
Correo Varchar2(50),
Telefono Varchar2(20)
);

CREATE TABLE RESERVA (
id_reserva NUMBER PRIMARY KEY,
rut Varchar2(50),
id_paquete NUMBER,
fecha_reserva DATE,
estado VARCHAR2(20),
CONSTRAINT fk_cliente_reserva FOREIGN KEY (rut) REFERENCES CLIENTE (rut),
CONSTRAINT fk_paquete_reserva FOREIGN KEY (id_paquete)REFERENCES AGENCIADEVIAJES (id_paquete)
);

CREATE TABLE PAGO (
id_pago NUMBER PRIMARY KEY,
id_reserva NUMBER,
CONSTRAINT fk_reserva_pago FOREIGN KEY (id_reserva) REFERENCES RESERVA (id_reserva)
);

CREATE TABLE AGENCIADEVIAJES (
id_paquete NUMBER PRIMARY KEY,
descripcion VARCHAR2(100),
precio NUMBER,
destino VARCHAR2(50),
vuelo VARCHAR2(50),
alojamiento VARCHAR2(50),
tour VARCHAR2(50),
fecha_inicio DATE,
fecha_termino DATE
);
