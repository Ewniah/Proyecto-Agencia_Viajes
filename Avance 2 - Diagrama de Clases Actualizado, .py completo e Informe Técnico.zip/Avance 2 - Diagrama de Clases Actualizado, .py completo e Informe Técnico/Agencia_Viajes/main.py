from crud import crear_cliente,autentica_usuario,mostrar_paquetes,crear_reserva,mostrar_reserva,crear_paquete, eliminar_paquete, modificar_cliente, eliminar_cliente
from clases import Agenciadeviajes 

class MenuPrincipal:
    def mostrar_menu(self):
        print("\n=== Menú Principal ===")
        print("1. Administrador")
        print("2. Usuario")
        print("3. Salir")
        return


class MenuAdmin:
    USUARIO_ADMIN = "admin"
    CONTRASENA_ADMIN = "1234"

    def autenticar(self):
        print("\n=== Autenticación de Administrador ===")
        usuario = input("Usuario: ")
        contrasena = input("Contraseña: ")
        if usuario == self.USUARIO_ADMIN and contrasena == self.CONTRASENA_ADMIN:
            print("Autenticación exitosa. Bienvenido Administrador.")
            return True
        else:
            print("Error: Usuario o contraseña incorrectos.")
            return False

    def mostrar_menu(self):
        if not self.autenticar():
            print("Regresando al Menú Principal...")
            return

        while True:
            print("\n=== Menú Administrador ===")
            print("1. Gestionar Paquetes de Viaje")
            print("2. Gestionar Usuarios")
            print("3. Salir al Menú Principal")
            opcion = input("Elige una opción: ")

            if opcion == "1":
                self.gestionar_paquetes()
            elif opcion == "2":
                self.gestionar_usuarios()
            elif opcion == "3":
                print("Regresando al Menú Principal...")
                break
            else:
                print("Opción no válida. Inténtalo de nuevo.")

    def gestionar_paquetes(self):
        while True:
            print("\n=== Gestión de Paquetes ===")
            print("1. Ver Paquetes")
            print("2. Crear Paquete")
            print("3. Eliminar Paquete")
            print("4. Regresar al Menú Administrador")
            opcion = input("Elige una opción: ")

            if opcion == "1":
                mostrar_paquetes()  # Llama a la función para mostrar los paquetes
            elif opcion == "2":
                crear_paquete()  # Llama a la función para crear un nuevo paquete
            elif opcion == "3":
                id_paquete = int(input("Ingrese el ID del paquete a eliminar: "))
                eliminar_paquete(id_paquete)  # Llama a la función para eliminar el paquete
                print(f"Paquete con ID {id_paquete} eliminado.")
            elif opcion == "4":
                break
            else:
                print("Opción no válida. Inténtalo de nuevo.")

    def gestionar_usuarios(self):
        while True:
            print("\n=== Gestión de Usuarios ===")
            print("1. Crear Usuario")
            print("2. Modificar Usuario")
            print("3. Eliminar Usuario")
            print("4. Regresar al Menú Administrador")

            opcion = input("Elige una opción: ")

            if opcion == "1":
                crear_cliente()  # Llama a la función para crear un nuevo cliente
            elif opcion == "2":
                modificar_cliente()  # Llama a la función para modificar un cliente
            elif opcion == "3":
                id_usuario = int(input("Ingrese el ID del usuario a eliminar: "))
                eliminar_cliente(id_usuario)  # Cambia esto para llamar a la función de eliminación
                print(f"Usuario con ID {id_usuario} eliminado.")
            elif opcion == "4":
                break
            else:
                print("Opción no válida. Inténtalo de nuevo.")


class MenuUsuario:
    def autenticacion_usuario(self):
        while True:
            print("\n=== Acceso Usuario ===")
            print("1. Registrarse")
            print("2. Iniciar sesión")
            print("3. Regresar al Menú Principal")
            opcion = input("\nElige una opción: ")

            if opcion == "1":
                crear_cliente()
            elif opcion == "2":
                if autentica_usuario()==True:
                    
                    self.mostrar_menu()
                     
            elif opcion == "3":
                return False  # Volver al Menú Principal
            else:
                print("Opción no válida. Inténtalo de nuevo.")

    def mostrar_menu(self):

        while True:
            print("\n=== Menú Usuario ===")
            print("1. Ver Paquetes de Viaje")
            print("2. Realizar Reserva")
            print("3. Detalles de Reserva")
            print("4. Salir al Menú Principal")
            opcion = input("\nElige una opción: ")

            if opcion == "1":
                print("Mostrando Paquetes.")
                mostrar_paquetes()
            elif opcion == "2":
                print("Reserva Realizada.")
                crear_reserva()
            elif opcion == "3":
                print("Mostrando detalles de la Reserva.")
                mostrar_reserva()  
            elif opcion == "4":
                print("Volviendo al menu...")
                break
            else:
                print("Opción no válida. Inténtalo de nuevo.")


def main():
    paquete1=Agenciadeviajes(1,'Paraiso veraniego',2000000,'Barcelona','LanChile','Hotel 5 Estrellas','Sin Tour','1-1-2025','14-1-2025')
    try:
        # Llamar al método agregar_paquete del objeto paquete1
        paquete1.agregar_paquete()
    except Exception as e:
        print(f"Error: {e}")
    menu_principal = MenuPrincipal()
    
    while True:
        menu_principal.mostrar_menu()
        opcion=int(input("\nIngrese una opcion: "))

        if opcion == 1:
            print("\nHas elegido ingresar como Administrador.")
            menu_admin = MenuAdmin()
            menu_admin.mostrar_menu()
        elif opcion == 2:
            print("\nHas ingresado como Usuario.")
            menu_usuario = MenuUsuario()
            menu_usuario.autenticacion_usuario()
        elif opcion == 3:
            print("\nSaliendo del programa. ¡Hasta pronto!")
            break
        else:
            print("\nOpción no válida. Inténtalo de nuevo.")

    
if __name__ == "__main__":
    main()