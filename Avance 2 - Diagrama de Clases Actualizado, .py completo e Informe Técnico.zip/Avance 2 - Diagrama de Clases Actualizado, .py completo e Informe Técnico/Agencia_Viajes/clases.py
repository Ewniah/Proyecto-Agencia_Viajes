from bd import hacer_consulta

class Agenciadeviajes:
    def __init__(self,id_paquete,descripcion,precio,destino,vuelo,alojamiento,tour,fecha_inicio,fecha_termino):
        self.id_paquete=id_paquete
        self.descripcion=descripcion
        self.precio=precio
        self.destino=destino
        self.vuelo=vuelo
        self.alojamineto=alojamiento
        self.tour=tour
        self.fecha_inicio=fecha_inicio
        self.fecha_termino=fecha_termino

    def agregar_paquete(self):
        query_buscar = "SELECT * FROM agenciadeviajes WHERE id_paquete = :id_paquete"
        variables_buscar = {'id_paquete': self.id_paquete}

        resultado = hacer_consulta(query_buscar, 'select', variables_buscar)
        
        if resultado:
            raise Exception(f"El paquete con ID {self.id_paquete} ya existe en la base de datos.")
        query = "Insert into agenciadeviajes values(:id,:descripcion,:precio,:destino,:vuelo,:alojamiento,:tour,:fecha_inicio,:fecha_termino)"
        variables = [self.id_paquete,self.descripcion,self.precio,self.destino,self.vuelo,self.alojamineto,self.tour,self.fecha_inicio,self.fecha_termino]
        hacer_consulta(query,'insert',variables)

    def eliminar_paquete(self):
        query = "DELETE FROM agenciadeviaje where id_paquete = :id"
        variables = [self.id_paquete]
        hacer_consulta(query,'delete',variables)

    def registrar_cliente(self):
        query = "Insert into cliente values(:rut,:nombre,:contraseña,:correo,:telefono)"
        variables = [self.get_rut(),self.get_nombre(),self.get_contrseña(),self.get_correo(),self.get_telefono()]
        hacer_consulta(query,'insert',variables)

    def eliminar_cliente(self):
        query = "DELETE FROM cliente where id_cliente = :id"
        variables = [self.id_cliente]
        hacer_consulta(query,'delete',variables)

    def agregar_paquete(self):
        query = "INSERT INTO agenciadeviajes (id_paquete, descripcion, precio, destino, vuelo, alojamiento, tour, fecha_inicio, fecha_termino) VALUES (:id,:descripcion,:precio,:destino,:vuelo,:alojamiento,:tour,:fecha_inicio,:fecha_termino)"
        variables = [self.id_paquete,self.descripcion,self.precio,self.destino,self.vuelo,self.alojamineto,self.tour,self.fecha_inicio,self.fecha_termino]
        hacer_consulta(query,'insert',variables)

    def eliminar_paquete(self):
        query = "DELETE FROM agenciadeviajes WHERE id_paquete = :id"
        variables = [self.id_paquete]
        hacer_consulta(query,'delete',variables)

class Reserva:
    def __init__(self,id_reserva,rut,id_paquete,fecha_reserva,estado):
        self.id_reserva=id_reserva
        self.__rut=rut
        self.id_paquete=id_paquete
        self.fecha_reserva=fecha_reserva
        self.estado=estado

    def get_rut(self):
        return self.__rut

    def cancelar_reserva(self,nuevo_estado):
        query = "Update reserva SET estado = :nuevo_estado where id_reserva = :id_reserva"
        variables = [nuevo_estado, self.id_reserva]
        hacer_consulta(query,'update', variables )

class Cliente:
    def __init__(self,rut=None,nombre=None,contraseña=None,correo=None,telefono=None):
        self.__rut=rut
        self.__nombre=nombre
        self.__contraseña=contraseña
        self.__correo=correo
        self.__telefono=telefono
    
    def get_nombre(self):
        return self.__nombre
    
    def get_contrseña(self):
        return self.__contraseña
    
    def get_rut(self):
        return self.__rut
    
    def get_correo(self):
        return self.__correo
    
    def get_telefono(self):
        return self.__telefono
    
    def realizar_reserva(self,reserva):
        query = "Insert into reserva values(:id_reserva,:rut,:id_paquete,:fecha_reserva,:estado)"
        variables = [reserva.id_reserva,reserva.get_rut(),reserva.id_paquete,reserva.fecha_reserva,reserva.estado]
        hacer_consulta(query,'insert',variables)

    def modificar_cliente(self):
        query = """
            UPDATE cliente 
            SET nombre = :nombre,
                contraseña = :contraseña,
                rut = :rut,
                correo = :correo,
                telefono = :telefono 
            WHERE id_cliente = :id
        """
        variables = {
            'nombre': self.get_nombre(),
            'contraseña': self.get_contraseña(),
            'rut': self.get_rut(),
            'correo': self.get_correo(),
            'telefono': self.get_telefono(),
            'id': self.get_id_cliente()
        }
        hacer_consulta(query, 'update', variables)


class Pago:
    def __init__(self,id_pago,id_reserva):
        self.id_pago=id_pago
        self.id_reserva=id_reserva

    def procesar_pago(self):
        query = "Insert into pago values(:id_pago,:id_reserva)"
        variables = [self.id_pago,self.id_reserva]
        hacer_consulta(query,'insert',variables)
