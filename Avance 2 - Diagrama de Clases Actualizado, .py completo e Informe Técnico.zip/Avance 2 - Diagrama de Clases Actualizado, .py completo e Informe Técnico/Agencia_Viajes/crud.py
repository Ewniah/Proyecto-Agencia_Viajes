from clases import Agenciadeviajes,Reserva,Cliente,Pago
from bd import hacer_consulta
import datetime

def crear_cliente():
    rut=input("Ingrese su Rut: ")
    nombre=input("Ingrese su Nombre: ")
    contraseña=input("Ingrese su Contraseña: ")
    correo=input("Ingrese su Correo: ")
    telefono=int(input("Ingrese su Telefono: "))

    cliente=Cliente(rut,nombre,contraseña,correo,telefono)
    agencia=Agenciadeviajes
    agencia.registrar_cliente(cliente)

def autentica_usuario():
    # Solicitar nombre de usuario y contraseña
    nombre_usuario = input("Ingrese su Nombre: ")
    contraseña = input("Ingrese su Contraseña: ")

    # Consulta para verificar usuario y contraseña
    query = "SELECT * FROM cliente WHERE nombre = :nombre AND contraseña = :contraseña"
    variables = {'nombre': nombre_usuario, 'contraseña': contraseña}

    # Hacer la consulta
    resultado = hacer_consulta(query, 'select', variables)

    # Verificar si el usuario existe
    if resultado:
        print("Inicio de sesión exitoso.")
        return True
        # Aquí puedes continuar con el flujo del menú o lo que sea necesario
    else:
        print("Usuario o contraseña incorrectos.")
        return False
    
def mostrar_paquetes():
    # Aquí especificas la tabla de la que quieres obtener los datos
    query = "SELECT * FROM agenciadeviajes"  # Cambia 'nombre_de_tu_tabla' por la tabla que quieres consultar
    
    # Ejecutar la consulta y obtener los resultados
    datos = hacer_consulta(query, 'select')

    if datos:  # Si hay resultados
        print("\n=== Paquete De Viaje Disponibles ===")
        for fila in datos:
            print(fila)  # Imprime cada fila de los resultados
    else:
        print("No se encontraron datos.")

def crear_paquete():
    id_paquete = int(input("Ingrese el ID del paquete: "))
    descripcion = input("Ingrese la descripción del paquete: ")
    precio = float(input("Ingrese el precio del paquete: "))
    destino = input("Ingrese el destino del paquete: ")
    vuelo = input("Ingrese la información del vuelo: ")
    alojamiento = input("Ingrese la información del alojamiento: ")
    tour = input("Ingrese información sobre el tour: ")
    fecha_inicio = input("Ingrese la fecha de inicio (DD-MM-YYYY): ")
    fecha_termino = input("Ingrese la fecha de término (DD-MM-YYYY): ")

    paquete = Agenciadeviajes(id_paquete, descripcion, precio, destino, vuelo, alojamiento, tour, fecha_inicio, fecha_termino)
    paquete.agregar_paquete()
    print(f"Paquete '{descripcion}' creado exitosamente.")

def eliminar_paquete(id_paquete):
    query = "DELETE FROM agenciadeviajes WHERE id_paquete = :id"
    variables = {'id': id_paquete}
    hacer_consulta(query, 'delete', variables)

def contador_id_reserva():
    query = "SELECT MAX(id_reserva) FROM reserva"
    resultado = hacer_consulta(query, 'select')
    if resultado[0][0] is None:
        return 1  # Si la tabla está vacía, el primer id será 1
    else:
        return resultado[0][0] + 1
    
def obtener_fecha_sistema():
    fecha_sistema = datetime.datetime.now()
    fecha_actual = fecha_sistema.date() 
    return fecha_actual
    
def crear_reserva():
    contador_id = contador_id_reserva()
    rut=input("Ingrese su Rut: ")
    id_paquete=input("Ingrese el Id del paquete Turistico: ")
    fecha_reserva=obtener_fecha_sistema()
    estado=input("Ingrese el estado: ")   

    reserva=Reserva(contador_id,rut,id_paquete,fecha_reserva,estado)
    cliente=Cliente()
    cliente.realizar_reserva(reserva)

def mostrar_reserva():
    # Aquí especificas la tabla de la que quieres obtener los datos
    query = "SELECT * FROM reserva"  
    
    # Ejecutar la consulta y obtener los resultados
    datos = hacer_consulta(query, 'select')

    if datos:  # Si hay resultados
        print("\n=== Reservas Realizadas ===")
        for fila in datos:
            print(fila)  # Imprime cada fila de los resultados
    else:
        print("No se encontraron datos.")

# def crear_cliente():
#     rut = input("Ingrese su Rut: ")
#     nombre = input("Ingrese su Nombre: ")
#     contraseña = input("Ingrese su Contraseña: ")
#     correo = input("Ingrese su Correo: ")
#     telefono = int(input("Ingrese su Telefono: "))
    
#     cliente = Cliente(rut, nombre, contraseña, correo, telefono)
#     agencia = Agenciadeviajes()
#     agencia.registrar_cliente(cliente)

def modificar_cliente():
    rut = int(input("Ingrese el ID del usuario a modificar: "))
    
    # Solicitar nuevos datos del cliente
    nombre = input("Ingrese el nuevo nombre: ")
    contraseña = input("Ingrese la nueva contraseña: ")
    # rut = input("Ingrese el nuevo RUT: ")
    correo = input("Ingrese el nuevo correo: ")
    telefono = int(input("Ingrese el nuevo teléfono: "))
    
    cliente = Cliente(rut, nombre, contraseña, correo, telefono)
    
    # Llamar al método para modificar el cliente
    cliente.modificar_cliente()
    
def eliminar_cliente(rut):
    query = "DELETE FROM cliente WHERE id_cliente = :id"
    variables = {'id': rut}
    hacer_consulta(query, 'delete', variables)

def mostrar_paquetes():
    query = "SELECT * FROM agenciadeviajes"
    datos = hacer_consulta(query, 'select')

    if datos:
        print("\n=== Paquetes De Viaje Disponibles ===")
        for fila in datos:
            print(f"ID: {fila[0]}, Descripción: {fila[1]}, Precio: {fila[2]}, Destino: {fila[3]}")
    else:
        print("No se encontraron paquetes disponibles.")
