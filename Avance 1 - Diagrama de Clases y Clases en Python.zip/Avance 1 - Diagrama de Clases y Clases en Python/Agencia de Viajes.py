class AgenciaDeViajes:
    def __init__(self, id_agencia, nombre, direccion):
        self.id_agencia = id_agencia
        self.nombre = nombre
        self.direccion = direccion
        self.__paquetes = []
        self.__clientes = []

    def agregar_paquete(self, paquete):
        self.__paquetes.append(paquete)

    def registrar_cliente(self, cliente):
        self.__clientes.append(cliente)

    def ver_paquetes_disponibles(self):
        return self.__paquetes

    def ver_clientes(self):
        return self.__clientes


class Cliente:
    def __init__(self, id_cliente, nombre, documento, correo, telefono, id_agencia):
        self.id_cliente = id_cliente
        self.nombre = nombre
        self.documento = documento
        self.correo = correo
        self.telefono = telefono
        self.id_agencia = id_agencia
        self.__reservas = []

    def realizar_reserva(self, reserva):
        self.__reservas.append(reserva)

    def ver_reservas(self):
        return self.__reservas


class ClienteEstandar(Cliente):
    def __init__(self, id_cliente, nombre, documento, correo, telefono, id_agencia):
        super().__init__(id_cliente, nombre, documento, correo, telefono, id_agencia)
        self.tipo_cliente = "Estandar"


class ClientePremium(Cliente):
    def __init__(self, id_cliente, nombre, documento, correo, telefono, id_agencia):
        super().__init__(id_cliente, nombre, documento, correo, telefono, id_agencia)
        self.tipo_cliente = "Premium"


class PaqueteDeViaje:
    def __init__(self, id_paquete, nombre, destino, precio, fechas_disponibles, descripcion, id_agencia, id_destino):
        self.id_paquete = id_paquete
        self.nombre = nombre
        self.destino = destino
        self.precio = precio
        self.fechas_disponibles = fechas_disponibles
        self.descripcion = descripcion
        self.id_agencia = id_agencia
        self.id_destino = id_destino

    def calcular_precio_total(self, extras):
        return self.precio + sum(extras)

    def ver_detalles(self):
        return f"Paquete {self.nombre}, Destino: {self.destino}, Precio: {self.precio}, Disponibilidad: {self.fechas_disponibles}"


class Reserva:
    def __init__(self, id_reserva, id_cliente, id_paquete, fecha_reserva, fecha_salida, estado):
        self.id_reserva = id_reserva
        self.id_cliente = id_cliente
        self.id_paquete = id_paquete
        self.fecha_reserva = fecha_reserva
        self.fecha_salida = fecha_salida
        self.estado = estado

    def cancelar_reserva(self):
        self.estado = "cancelada"

    def cambiar_fecha_salida(self, nueva_fecha):
        self.fecha_salida = nueva_fecha

    def obtener_detalles_reserva(self):
        return f"Reserva ID: {self.id_reserva}, Cliente: {self.id_cliente}, Paquete: {self.id_paquete}, Estado: {self.estado}"


class Pago:
    def __init__(self, id_pago, id_reserva, monto, fecha_pago, metodo_de_pago):
        self.id_pago = id_pago
        self.id_reserva = id_reserva
        self.monto = monto
        self.fecha_pago = fecha_pago
        self.metodo_de_pago = metodo_de_pago

    def procesar_pago(self):
        return f"Procesando pago de {self.monto} para la reserva {self.id_reserva}"

    def obtener_detalles_pago(self):
        return f"Pago ID: {self.id_pago}, Monto: {self.monto}, Metodo de pago: {self.metodo_de_pago}"


class Vuelo:
    def __init__(self, id_vuelo, aerolinea, numero_de_vuelo, origen, destino, fecha_salida, fecha_llegada, precio, id_paquete):
        self.id_vuelo = id_vuelo
        self.aerolinea = aerolinea
        self.numero_de_vuelo = numero_de_vuelo
        self.origen = origen
        self.destino = destino
        self.fecha_salida = fecha_salida
        self.fecha_llegada = fecha_llegada
        self.precio = precio
        self.id_paquete = id_paquete

    def ver_detalles_vuelo(self):
        return f"Vuelo {self.numero_de_vuelo}, Aerolinea: {self.aerolinea}, De: {self.origen} A: {self.destino}"

    def calcular_precio(self):
        return self.precio


class Alojamiento:
    def __init__(self, id_alojamiento, nombre_hotel, direccion, tipo_de_habitacion, precio_noche, servicios_incluidos, id_paquete):
        self.id_alojamiento = id_alojamiento
        self.nombre_hotel = nombre_hotel
        self.direccion = direccion
        self.tipo_de_habitacion = tipo_de_habitacion
        self.precio_noche = precio_noche
        self.servicios_incluidos = servicios_incluidos
        self.id_paquete = id_paquete

    def obtener_precio_total(self, noches):
        return self.precio_noche * noches

    def ver_detalles_hotel(self):
        return f"Hotel: {self.nombre_hotel}, Tipo de Habitación: {self.tipo_de_habitacion}, Precio por Noche: {self.precio_noche}"


class Tour:
    def __init__(self, id_tour, nombre_tour, duracion, precio, lugar, descripcion, id_paquete):
        self.id_tour = id_tour
        self.nombre_tour = nombre_tour
        self.duracion = duracion
        self.precio = precio
        self.lugar = lugar
        self.descripcion = descripcion
        self.id_paquete = id_paquete

    def ver_detalles_tour(self):
        return f"Tour {self.nombre_tour}, Duración: {self.duracion} horas, Lugar: {self.lugar}"

    def calcular_precio_total(self, extras):
        return self.precio + sum(extras)


class Destino:
    def __init__(self, id_destino, nombre, descripcion, atracciones_principales, clima, moneda):
        self.id_destino = id_destino
        self.nombre = nombre
        self.descripcion = descripcion
        self.atracciones_principales = atracciones_principales
        self.clima = clima
        self.moneda = moneda

    def ver_detalles_destino(self):
        return f"Destino: {self.nombre}, Clima: {self.clima}, Moneda: {self.moneda}"

    def obtener_informacion_clima(self):
        return f"Clima de {self.nombre}: {self.clima}"


class Empleado:
    def __init__(self, id_empleado, nombre, puesto, salario, id_agencia):
        self.id_empleado = id_empleado
        self.nombre = nombre
        self.puesto = puesto
        self.salario = salario
        self.id_agencia = id_agencia

    def gestionar_reserva(self):
        return "Gestionando reserva"

    def modificar_paquete(self, paquete):
        return f"Modificando paquete {paquete.nombre}"
